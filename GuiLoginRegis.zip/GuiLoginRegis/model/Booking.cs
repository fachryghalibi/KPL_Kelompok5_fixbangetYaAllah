﻿namespace GuiLoginRegis
{
    public class Booking
    {
        public string Nama { get; set; }
        public string Nim { get; set; }
        public string Tanggal { get; set; }
        public string Jam { get; set; }
        public string Status { get; set; }
    }
}
